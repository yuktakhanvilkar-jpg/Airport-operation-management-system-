# Airport Control System

A browser-based Airport Control System built for a DBMS project. It manages flight/airline information, terminal allocation, crew and passenger records using PostgreSQL on Supabase.

## Features

- Controller registration and login using Supabase Authentication
- Airport data stored in PostgreSQL
- CRUD operations (create, read, update, delete) for flights, terminals, crew and passengers
- Search within each board
- Departure-board inspired interface with live date/time
- Terminal status indicators
- Primary, composite and foreign keys
- `NOT NULL`, `UNIQUE` and `CHECK` constraints
- Controller registration trigger and row-level security
- Three reporting views and a collection of SQL practice/reporting queries

## Technology stack

- HTML5, CSS3 and vanilla JavaScript
- PostgreSQL hosted on Supabase
- Supabase Auth and auto-generated REST API
- GitHub Pages for static frontend hosting

## Repository layout

```text
airport-control-system/
├── frontend/
│   └── index.html
├── database/
│   ├── schema_and_data.sql
│   └── queries.sql
├── documentation/
│   └── PROJECT_SETUP.md
├── testing/
│   └── TEST_PLAN.md
├── screenshots/
│   └── README.md
├── .gitignore
└── README.md
```

## Setup: create your own Supabase database

1. Sign in to [Supabase](https://supabase.com/) and create a new project under your account.
2. Open **SQL Editor** in the new project.
3. Open `database/schema_and_data.sql`, copy the complete script and run it.
4. Check **Table Editor**. The script creates `crew`, `flight`, `passenger`, `terminal` and `controller`, inserts sample records, adds constraints, the registration trigger, RLS policies and views.
5. Open **Project Settings → API** (or the project's Connect/API details) and copy:
   - Project URL
   - Publishable/anon public key
6. Open the root-level `index.html` (this is the file GitHub Pages serves). Replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_PUBLIC_KEY` with your own Supabase values. Make the same replacements in `frontend/index.html` so both copies stay in sync.
7. Save the files and open the root `index.html` locally in a browser to test. Registration and login require the Supabase project to be configured correctly.
8. In Supabase **Authentication → URL Configuration**, add your eventual GitHub Pages URL to the allowed redirect/site URLs if your authentication settings require it.

> Use only the Supabase publishable/anon public key in browser code. Never put a `service_role` or secret key in `index.html` or a public GitHub repository.

## Publish on your GitHub account

1. Create a new repository, for example `airport-control-system`.
2. Upload the contents of this folder (the files inside `airport_control_system`, not an extra nested folder).
3. In repository **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)` only if `index.html` is in the repository root.  
   **Recommended:** move/copy `frontend/index.html` to the repository root, or configure the repository so the Pages publishing source points to the `frontend` folder using GitHub Actions. The simplest option is to place `index.html` at root.
4. After Pages deploys, open the generated URL and test registration, login and CRUD.
5. Replace the placeholder repository/deployment links in your report with your own URLs.

## Important note about GitHub Pages

GitHub Pages hosts static files only. The database and authentication remain hosted on Supabase. The frontend calls Supabase's REST and Auth endpoints directly; there is no separate custom application server.

## Data model

- `flight`: flight and airline details. Composite primary key: (`flight_id`, `airline_id`); `airline_id` is also unique.
- `crew`: crew members and their airline association.
- `passenger`: passenger details, passport identifier, airline association and date of birth.
- `terminal`: terminal number, flight assignment and status.
- `controller`: profile linked to the Supabase Auth user.

The current model intentionally mirrors the supplied project report: a passenger is associated with an airline, not an individual flight; `flight.terminal_number` is a plain integer field; all authenticated controllers share the same access level.

## SQL

Run `database/queries.sql` in the Supabase SQL Editor after the schema script. Update or delete examples are commented out to avoid accidental modification of sample records.

## Testing

See `testing/TEST_PLAN.md`. Take screenshots of your own deployment and add them to `screenshots/` after testing.

## Credits and academic integrity

This repository is a personal GitHub copy/reconstruction of the group Airport Control System project. Retain the original group-member credits in the academic report where appropriate. Do not claim deployment or test results until you have performed them on your own Supabase project and GitHub Pages site.
