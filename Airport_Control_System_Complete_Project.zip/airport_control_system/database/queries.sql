-- Airport Control System: SQL query collection (PostgreSQL)

-- Q1: Display all flight records.
select * from flight;

-- Q2: Flights with capacity greater than 200.
select flight_id,airline_name,capacity from flight where capacity>200;

-- Q3: Flights sorted by capacity, highest first.
select flight_id,airline_name,capacity from flight order by capacity desc;

-- Q4: List unique destinations.
select distinct destination from flight order by destination;

-- Q5: Passengers whose names start with A.
select passenger_id,name from passenger where name ilike 'A%';

-- Q6: Flights with capacity between 150 and 300.
select flight_id,airline_name,capacity from flight where capacity between 150 and 300;

-- Q7: Aggregate statistics for flight capacity.
select count(*) as flight_count,avg(capacity) as average_capacity,
       min(capacity) as minimum_capacity,max(capacity) as maximum_capacity
from flight;

-- Q8: Passenger count by airline.
select airline_id,count(*) as passenger_count
from passenger group by airline_id order by airline_id;

-- Q9: Airlines with more than five passengers.
select airline_id,count(*) as passenger_count
from passenger group by airline_id having count(*)>5;

-- Q10: Flights and their lead crew members.
select f.flight_id,f.airline_name,c.name as crew_name
from flight f inner join crew c on f.crew_id=c.crew_id;

-- Q11: All crew members and any flight assigned to them.
select c.crew_id,c.name,f.flight_id
from crew c left join flight f on c.crew_id=f.crew_id;

-- Q12: Passenger details with airline and destination.
select p.passenger_id,p.name,f.flight_id,f.airline_name,f.destination
from passenger p join flight f on p.airline_id=f.airline_id;

-- Q13: Flights with above-average capacity.
select flight_id,airline_name,capacity from flight
where capacity>(select avg(capacity) from flight);

-- Q14: Crew members assigned to at least one flight.
select c.crew_id,c.name from crew c
where exists(select 1 from flight f where f.crew_id=c.crew_id);

-- Q15: Update a terminal's status (example; change terminal number as needed).
-- update terminal set status='Free' where terminal_no=1;

-- Q16: Delete a passenger record (example; use a test passenger ID).
-- delete from passenger where passenger_id=45;

-- Q17: Terminal status with flight details (view).
select * from v_terminal_status order by terminal_no;

-- Q18: Flight and crew summary (view).
select * from v_flight_crew order by arrival_time;

-- Q19: Airline-level passenger and crew summary (view).
select * from v_airline_summary order by airline_id;

-- Q20: Rank flights by seat capacity.
select flight_id,airline_name,capacity,
       rank() over(order by capacity desc) as capacity_rank
from flight;

-- Q21: Passenger count by airline, including airline name.
select f.airline_name,count(p.passenger_id) as passenger_count
from flight f left join passenger p on p.airline_id=f.airline_id
group by f.airline_id,f.airline_name order by passenger_count desc;

-- Q22: Find terminals not currently assigned to a flight.
select terminal_no,status from terminal where flight_id is null;

-- Q23: Find passengers born after 2000-01-01.
select passenger_id,name,dob from passenger where dob>'2000-01-01' order by dob;

-- Q24: Crew members whose phone number is present.
select crew_id,name,phone_number from crew where phone_number is not null;

-- Q25: Count terminals by status.
select status,count(*) as terminal_count from terminal group by status order by status;
