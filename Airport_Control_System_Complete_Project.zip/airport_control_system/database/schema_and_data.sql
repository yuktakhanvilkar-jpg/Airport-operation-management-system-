-- Airport Control System - PostgreSQL / Supabase
-- Run this script in Supabase SQL Editor in a NEW project.
-- It recreates the application tables and sample data. Do not run on a database
-- containing unrelated production data.

drop view if exists v_terminal_status cascade;
drop view if exists v_flight_crew cascade;
drop view if exists v_airline_summary cascade;
drop table if exists terminal, passenger, flight, crew, controller cascade;

create table crew (
  crew_id int primary key,
  name text not null,
  role text not null,
  airline_id int,
  phone_number text check (phone_number ~ '^[0-9]{10}$')
);

create table flight (
  flight_id text not null,
  airline_id int not null unique,
  airline_name text not null,
  terminal_number int,
  capacity int not null check (capacity > 0),
  crew_id int,
  destination text,
  arrival_time timestamp,
  primary key (flight_id, airline_id)
);

create table passenger (
  passenger_id int primary key,
  name text not null,
  passport_details text not null unique,
  airline_id int,
  seat_number text,
  phone_number text check (phone_number ~ '^[0-9]{10}$'),
  dob date check (dob <= current_date)
);

create table terminal (
  terminal_no int primary key,
  flight_id text,
  status text not null default 'Free'
    check (status in ('Occupied','Free','Expecting Arrival','Under Maintenance')),
  airline_id int
);

-- Sample data: 40 crew, 30 flights, 45 passengers and 40 terminals.
insert into crew
select i,
  (array['Rahul','Priya','Amit','Sneha','Vikram','Anjali','Rohan','Neha','Karan','Pooja'])[i%10+1] || ' ' ||
  (array['Sharma','Patel','Singh','Iyer','Nair','Kulkarni','Mehta','Joshi'])[i%8+1],
  (array['Pilot','Co-pilot','Cabin Crew','Flight Engineer'])[i%4+1],
  (i-1)%30+1,
  '9' || lpad(((i*7654321) % 1000000000)::text,9,'0')
from generate_series(1,40) i;

with airlines as (
  select i,
    (array['Air India','IndiGo','SpiceJet','Vistara','Akasa Air','Air India Express','Alliance Air',
      'Emirates','Qatar Airways','Etihad','Singapore Airlines','Lufthansa','British Airways',
      'Air France','KLM','Turkish Airlines','Thai Airways','Cathay Pacific','Qantas','Delta',
      'United','American Airlines','Air Canada','Japan Airlines','Korean Air','Saudia',
      'Oman Air','Gulf Air','Kuwait Airways','Swiss'])[i] as airline_name,
    (array['AI','6E','SG','UK','QP','IX','9I','EK','QR','EY','SQ','LH','BA','AF','KL','TK','TG',
      'CX','QF','DL','UA','AA','AC','JL','KE','SV','WY','GF','KU','LX'])[i] as code
  from generate_series(1,30) i
)
insert into flight (flight_id,airline_id,airline_name,terminal_number,capacity,crew_id,destination,arrival_time)
select code || (100+i*7), i, airline_name, i, 150+(i%6)*30, i,
  (array['Delhi','Mumbai','Dubai','London','Singapore','Paris','Doha','Bangkok','Tokyo',
    'Frankfurt','Sydney','Toronto','Seoul','Riyadh','Muscat'])[i%15+1],
  timestamp '2026-10-05 06:00' + i*interval '47 minutes'
from airlines;

insert into passenger
select i,
  (array['Aarav','Diya','Ishaan','Meera','Kabir','Tara','Arjun','Nisha','Dev','Riya'])[i*3%10+1] || ' ' ||
  (array['Reddy','Gupta','Desai','Menon','Bose','Verma','Kapoor','Rao'])[i*5%8+1],
  'P' || lpad(((i*1234567)%10000000)::text,7,'0'),
  (i-1)%30+1,
  (i%30+1) || (array['A','B','C','D','E','F'])[i%6+1],
  '8' || lpad(((i*9876543)%1000000000)::text,9,'0'),
  date '1965-03-01' + i*331
from generate_series(1,45) i;

insert into terminal
select i,
  case when i<=30 then f.flight_id end,
  case when i<=30 then (case when i%2=0 then 'Occupied' else 'Expecting Arrival' end)
       when i<=35 then 'Free' else 'Under Maintenance' end,
  case when i<=30 then i end
from generate_series(1,40) i
left join flight f on f.airline_id=i;

-- Add circular and composite foreign keys after sample rows have been inserted.
alter table flight add constraint flight_crew_fk
  foreign key (crew_id) references crew(crew_id) on delete set null;
alter table crew add constraint crew_airline_fk
  foreign key (airline_id) references flight(airline_id) on delete set null;
alter table passenger add constraint passenger_airline_fk
  foreign key (airline_id) references flight(airline_id) on delete set null;
alter table terminal add constraint terminal_flight_airline_fk
  foreign key (flight_id,airline_id) references flight(flight_id,airline_id) on delete set null;

-- Controller profile created automatically after Supabase Auth signup.
create table controller (
  controller_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  employee_id text not null unique,
  email text not null unique,
  phone_number text not null check (phone_number ~ '^[0-9]{10}$'),
  shift text not null default 'Morning' check (shift in ('Morning','Evening','Night')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_controller()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.controller(controller_id,full_name,employee_id,email,phone_number,shift)
  values (
    new.id,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'employee_id',
    new.email,
    new.raw_user_meta_data->>'phone_number',
    coalesce(nullif(new.raw_user_meta_data->>'shift',''),'Morning')
  );
  return new;
end;
$$;

drop trigger if exists on_controller_signup on auth.users;
create trigger on_controller_signup
after insert on auth.users
for each row execute procedure public.handle_new_controller();

-- Enable RLS. Airport tables are accessible only to authenticated controllers.
do $$
declare table_name text;
begin
  foreach table_name in array array['crew','passenger','flight','terminal'] loop
    execute format('alter table public.%I enable row level security',table_name);
    execute format('drop policy if exists staff_only on public.%I',table_name);
    execute format('create policy staff_only on public.%I for all to authenticated using (true) with check (true)',table_name);
    execute format('grant select,insert,update,delete on public.%I to authenticated',table_name);
  end loop;
end $$;

alter table controller enable row level security;
drop policy if exists own_profile_read on controller;
drop policy if exists own_profile_update on controller;
create policy own_profile_read on controller for select to authenticated
  using (controller_id = auth.uid());
create policy own_profile_update on controller for update to authenticated
  using (controller_id = auth.uid()) with check (controller_id = auth.uid());
grant select,update on controller to authenticated;

-- The views use security_invoker so the underlying table RLS is respected.
create or replace view v_terminal_status with (security_invoker=true) as
select t.terminal_no,t.status,t.flight_id,f.airline_name,f.destination,f.arrival_time
from terminal t
left join flight f on t.flight_id=f.flight_id and t.airline_id=f.airline_id;

create or replace view v_flight_crew with (security_invoker=true) as
select f.flight_id,f.airline_name,f.destination,f.arrival_time,f.capacity,
       c.name as crew_name,c.role as crew_role,c.phone_number as crew_phone
from flight f left join crew c on f.crew_id=c.crew_id;

create or replace view v_airline_summary with (security_invoker=true) as
select f.airline_id,f.airline_name,f.capacity,
  (select count(*) from passenger p where p.airline_id=f.airline_id) as passenger_count,
  (select count(*) from crew c where c.airline_id=f.airline_id) as crew_count
from flight f;

grant select on v_terminal_status,v_flight_crew,v_airline_summary to authenticated;
