# Test Plan

Record the actual outcome after running each test against your own Supabase project. Do not mark a test as passed before executing it.

| ID | Test | Steps | Expected result | Actual result |
|---|---|---|---|---|
| AUTH-01 | Controller registration | Register with valid profile details | Auth user and controller profile are created | Pending |
| AUTH-02 | Duplicate employee ID | Register another account with an existing employee ID | Registration is rejected by unique constraint/trigger | Pending |
| AUTH-03 | Invalid phone | Enter a phone number other than 10 digits | Frontend blocks submission | Pending |
| AUTH-04 | Login | Log in with valid credentials | Airport dashboard appears | Pending |
| AUTH-05 | Logout | Click Log out | Session is cleared and login screen appears | Pending |
| CRUD-01 | Add flight | Add a flight with valid required fields | Flight appears on Flights board | Pending |
| CRUD-02 | Edit flight | Change a non-key field and save | Updated value appears | Pending |
| CRUD-03 | Delete flight | Delete a test flight | Record is removed; FK actions are applied | Pending |
| CRUD-04 | Add terminal | Add terminal with valid status | Terminal appears on board | Pending |
| CRUD-05 | Add crew | Add a crew member with valid phone | Crew record appears | Pending |
| CRUD-06 | Add passenger | Add passenger with unique passport details | Passenger appears on board | Pending |
| SEARCH-01 | Search record | Search for a known name or ID | Matching rows are displayed | Pending |
| DB-01 | Duplicate primary key | Insert duplicate primary key | Database rejects insert | Pending |
| DB-02 | Duplicate passport | Insert an existing passport value | Unique constraint rejects insert | Pending |
| DB-03 | Invalid capacity | Insert zero/negative capacity | Check constraint rejects insert | Pending |
| DB-04 | Invalid terminal status | Insert a status outside allowed values | Check constraint rejects insert | Pending |
| DB-05 | Invalid foreign key | Link a record to a non-existent parent | Foreign key rejects insert | Pending |
| RLS-01 | Anonymous read | Call an airport table endpoint without a user session | No airport records are returned | Pending |
| RLS-02 | Authenticated read | Sign in and load a board | Records are returned | Pending |
| VIEW-01 | Terminal view | Query `v_terminal_status` while signed in | Terminal and flight details are returned | Pending |

## Evidence to capture

Capture your own screenshots of the repository, Pages deployment, login screen, registration screen, each data board, add/edit/delete operations, Supabase tables, views and representative SQL query results. Store them in `screenshots/`.
