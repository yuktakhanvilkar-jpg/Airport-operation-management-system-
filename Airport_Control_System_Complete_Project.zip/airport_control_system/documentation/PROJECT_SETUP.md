# Project Setup and Architecture

## Architecture

The system follows a two-tier architecture:

1. **Presentation tier:** `frontend/index.html`, opened in a browser and hosted as a static site on GitHub Pages.
2. **Data tier:** PostgreSQL hosted by Supabase. Supabase exposes a REST API and authentication endpoints consumed by the browser.

No separate application server is included. The browser sends HTTPS requests to Supabase. Authentication returns a session token; authenticated requests use that token in the `Authorization` header.

## Registration flow

1. A controller enters their name, employee ID, email, phone number, shift and password.
2. The frontend submits the credentials and profile metadata to Supabase Auth.
3. A PostgreSQL trigger on `auth.users` inserts the controller's profile into `public.controller`.
4. The controller signs in and receives an access token.
5. Row-level security permits authenticated users to access airport records and limits controller profile reads/updates to the matching `auth.uid()`.

## Database relationships

- `flight.crew_id` references `crew.crew_id`.
- `crew.airline_id` references the unique `flight.airline_id`.
- `passenger.airline_id` references `flight.airline_id`.
- (`terminal.flight_id`, `terminal.airline_id`) references the composite key (`flight.flight_id`, `flight.airline_id`).

The foreign keys are added after sample data insertion because the flight and crew tables refer to each other.

## Configuration checklist

- [ ] Create a new Supabase project owned by you.
- [ ] Run `database/schema_and_data.sql`.
- [ ] Confirm the four airport tables and controller table exist.
- [ ] Replace the Supabase URL and public key placeholders in the root `index.html` and `frontend/index.html`.
- [ ] Confirm Auth email settings are appropriate for your testing.
- [ ] Add the deployed site URL to Supabase Auth URL configuration if required.
- [ ] Test signup, login, logout and CRUD.
- [ ] Publish the frontend from your own GitHub repository.
- [ ] Replace all placeholders in the report with your actual repository and Pages URLs.

## Security notes

The anon/public key is designed for client-side use when row-level security is correctly configured. The service-role key bypasses RLS and must never be exposed in browser code or committed to GitHub. This project gives all authenticated controllers the same permissions; it does not implement separate administrator and staff roles.
