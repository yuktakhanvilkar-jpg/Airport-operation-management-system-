# Screenshots

Add genuine screenshots captured from your own Supabase project and GitHub Pages deployment here. Suggested names: `repository.png`, `login.png`, `flights-board.png`, `terminal-board.png`, `crud-add.png`, `crud-edit.png`, `crud-delete.png`, `sql-views.png`.
